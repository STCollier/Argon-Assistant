To Launch Argon:

In the "Argon Files" folder, open the folder "Main."

Then, click on the file "index.html" to launch.